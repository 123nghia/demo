-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: hovi_cms
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_zone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`),
  KEY `blogs_is_published_sort_order_index` (`is_published`,`sort_order`),
  KEY `blogs_published_at_index` (`published_at`),
  KEY `blogs_project_id_is_published_index` (`project_id`,`is_published`),
  KEY `blogs_visibility_zone_published_idx` (`is_published`,`display_zone`,`published_at`),
  CONSTRAINT `blogs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,NULL,'Tổng hợp thiết kế nội thất tại Green Villas: Những lát cắt Modern Luxury','tong-hop-thiet-ke-noi-that-tai-green-villas-nhung-lat-cat-modern-luxury','all','Mỗi công trình tại Vinhomes Green Villas là một lát cắt khác nhau của Modern Luxury: hiện đại, sang trọng nhưng luôn phù hợp thói quen sống của gia chủ.','<p>Mỗi công trình tại Vinhomes Green Villas là một minh chứng cho cách định nghĩa thiết kế nội thất hiện đại: tinh gọn, chuẩn mực và giàu cảm xúc sống. Dưới đây là những lát cắt tiêu biểu của bộ sưu tập dự án được triển khai thực tế.</p>\n<h3>GV11-02 – Tinh thần hiện đại thể hiện qua vật liệu và bố cục</h3>\n<p>Không gian khách – bếp mở rộng liền mạch, lấy trục chính là vách đá Quartz nguyên khối xuyên thông tầng. Bảng màu trung tính ấm được nhấn bằng gỗ, kim loại ánh đồng và hệ đèn điểm mềm.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/GV11-02.jpg\" alt=\"Vinhomes Green Villas GV11-02\"></p>\n<h3>GV7-06 – Nâu gỗ cổ điển, sang trọng</h3>\n<p>Bảng màu trầm ấm với gỗ tự nhiên, ánh sáng vàng và các chi tiết pha lê tạo nên bầu không khí quý phái nhưng không nặng nề. Bố cục mở giúp tổng thể vẫn thông thoáng và giàu nhịp điệu.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/GV7-06-2.jpg\" alt=\"Vinhomes Green Villas GV7-06\"></p>\n<h3>GV12-09 – Sự chuyển tiếp tinh tế giữa ánh sáng, vật liệu và không gian</h3>\n<p>Đá xám, gỗ nâu và ánh sáng vàng dịu được phối theo mảng lớn để mang lại cảm giác thư giãn. Khu khách – bếp đồng bộ về ngôn ngữ thiết kế, tối ưu tiện nghi cho sinh hoạt hàng ngày.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/GV12-09-3.jpg\" alt=\"Vinhomes Green Villas GV12-09\"></p>','https://rhinelux.com/wp-content/uploads/2025/06/GV11-02.jpg','Tổng hợp thiết kế nội thất tại Green Villas | Modern Luxury','Tổng hợp các dự án nội thất Green Villas với nhiều lát cắt Modern Luxury: bố cục, vật liệu và giải pháp tối ưu trải nghiệm sống.','2025-06-20 10:30:00',1,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(2,NULL,'Biệt thự đơn lập phong cách Modern Luxury tại Vinhomes Green Villas','biet-thu-don-lap-phong-cach-modern-luxury-tai-vinhomes-green-villas','blog','Khối nhà 3 tầng + mái áp được xử lý tinh gọn, mở tối đa ánh sáng tự nhiên và kết nối mạnh với sân vườn để tạo trải nghiệm sống nghỉ dưỡng.','<p>Ẩn mình trong khuôn viên xanh của Green Villas, căn biệt thự GV11-02 là một ví dụ điển hình cho Modern Luxury: khối hình rõ ràng, vật liệu chọn lọc và công năng tối ưu theo nhịp sống gia chủ.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/DSC09037-copy.jpg\" alt=\"Thiết kế sân vườn Green Villas\"></p>\n<h3>Tầng 1 – Khách | Bếp | Sân vườn</h3>\n<p>Mặt bằng liên thông giúp phòng khách và bếp ăn kết nối mạch lạc. Vách đá vân tự nhiên, tủ bếp âm tường và đảo bếp nhỏ gọn tạo cảm giác sang trọng nhưng không phô trương.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/DSC09077-copy.jpg\" alt=\"Phòng khách Modern Luxury\"></p>\n<h3>Tầng 3 – Master Suite &amp; Phòng ngủ phụ</h3>\n<p>Khu master được thiết kế theo tinh thần “retreat” với bảng màu trung tính, ánh sáng gián tiếp và hệ tủ tối giản. Không gian mang lại sự riêng tư, thư giãn và linh hoạt sử dụng.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/4_Interactive-LightMix-2.jpg\" alt=\"Phòng ngủ master\"></p>','https://rhinelux.com/wp-content/uploads/2025/06/DSC09077-copy.jpg','Biệt thự đơn lập phong cách Modern Luxury tại Green Villas','Khám phá thiết kế biệt thự Modern Luxury tại Green Villas với bố cục mở, ánh sáng tự nhiên và vật liệu cao cấp.','2025-06-11 09:00:00',2,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(3,NULL,'Hiệu chỉnh thiết kế 3D biệt thự Louis City Hoàng Mai: Khi bản thiết kế trở nên “có hồn”','hieu-chinh-thiet-ke-3d-biet-thu-louis-city-hoang-mai-khi-ban-thiet-ke-tro-nen-co-hon','blog','Một bản 3D đẹp chưa phải đích đến cuối cùng. Giá trị thực nằm ở các vòng hiệu chỉnh công năng, vật liệu, kỹ thuật và trải nghiệm sống trước khi thi công.','<p>Hiệu chỉnh 3D là bước “chốt hạ” quan trọng giúp bản thiết kế đi từ đẹp về hình ảnh sang khả thi khi triển khai. Dự án Louis City Hoàng Mai cho thấy rõ vai trò của bước này trong thực tế.</p>\n<h3>Kiến trúc mặt ngoài: Tỉ lệ, kết nối và giới hạn cải tạo</h3>\n<p>Cao độ tầng 1 lớn tạo cảm giác bề thế nhưng làm đứt kết nối với sân vườn. Phương án chỉnh sửa tập trung vào xử lý tỷ lệ, vật liệu bề mặt và tổ chức cảnh quan an toàn quanh nhà.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/07/ARCHITECTURE-9.jpg\" alt=\"Thiết kế kiến trúc biệt thự Louis City\"></p>\n<h3>Sảnh đón khách &amp; khu khách – bếp</h3>\n<p>Điểm nhìn, tỷ lệ khối tủ, trần và ánh sáng được rà soát lại để không gian mạch lạc, dễ dùng. Mỗi chi tiết đều được cân đối lại để giữ đúng tinh thần thiết kế ban đầu.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/07/Sanh-ngoai.jpg\" alt=\"Sảnh đón khách\"></p>\n<h3>Góc nhìn cuối cùng</h3>\n<p>Hiệu chỉnh 3D giúp tháo gỡ vướng mắc kỹ thuật trước khi thi công, giảm rủi ro phát sinh và đảm bảo công trình bàn giao đúng công năng – đúng cảm xúc.</p>','https://rhinelux.com/wp-content/uploads/2025/07/ARCHITECTURE-9.jpg','Hiệu chỉnh thiết kế 3D biệt thự Louis City Hoàng Mai','Toàn cảnh quá trình hiệu chỉnh thiết kế 3D biệt thự Louis City Hoàng Mai để tối ưu công năng, kỹ thuật và trải nghiệm sống.','2025-07-21 10:15:00',3,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(4,NULL,'Tổng hợp các mẫu thiết kế nội thất biệt thự tại Vinhomes Cổ Loa: Layout mẫu','tong-hop-cac-mau-thiet-ke-noi-that-biet-thu-tai-vinhomes-co-loa-layout-mau','blog','Bộ layout thực tế cho dòng biệt thự song lập, liền kề tại Vinhomes Cổ Loa, kết hợp kinh nghiệm thiết kế và thi công nội thất đa khu đô thị.','<p>Vinhomes Cổ Loa là bài toán thiết kế – thi công đòi hỏi hiểu sâu kết cấu, thông số và thói quen sử dụng thực tế. Bộ layout mẫu dưới đây tổng hợp các phương án đang triển khai thực tế.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2026/03/Layout-BT-song-lap-DH.png\" alt=\"Layout biệt thự song lập ĐH\"></p>\n<h3>5 hướng giải pháp tiêu biểu</h3>\n<ul>\n  <li>Xử lý thông tầng và mảng đá khổ lớn đồng bộ trần – tường.</li>\n  <li>Tối ưu mặt bằng liền kề theo trục giao thông và điểm nhìn.</li>\n  <li>Đưa năng lực sản xuất thủ công vào các chi tiết có độ khó cao.</li>\n  <li>Thi công sàn gỗ xương cá và nội thất bo góc theo tiêu chuẩn bàn giao cao.</li>\n  <li>Tích hợp giải pháp thang máy kính và khung chịu lực trong không gian ở.</li>\n</ul>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2026/03/CAH_TANG-1-3.jpg\" alt=\"Thiết kế nội thất biệt thự song lập Vin Cổ Loa\"></p>','https://rhinelux.com/wp-content/uploads/2026/03/CAH_TANG-1-3.jpg','Layout mẫu thiết kế nội thất biệt thự Vinhomes Cổ Loa','Tổng hợp layout mẫu nội thất biệt thự tại Vinhomes Cổ Loa với giải pháp thi công thực tế và tối ưu công năng.','2026-03-16 08:45:00',4,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(7,NULL,'Tổng hợp thiết kế phòng ngủ master biệt thự tại Vinhomes: Không gian riêng tư đẳng cấp','tong-hop-thiet-ke-phong-ngu-master-biet-thu-tai-vinhomes','blog','Từ tỷ lệ giường – tủ – ánh sáng đến tổ chức khu thay đồ, bài viết tổng hợp các nguyên tắc thiết kế master suite sang trọng và tối ưu công năng.','<p>Phòng ngủ master không chỉ là nơi nghỉ ngơi mà còn là không gian tái tạo năng lượng. Một thiết kế tốt cần đồng thời đạt ba tiêu chí: riêng tư, thư giãn và linh hoạt sử dụng.</p>\n<h3>Ba nguyên tắc cốt lõi</h3>\n<ul>\n  <li>Giữ trục giao thông gọn, tránh xung đột giữa giường ngủ và khu thay đồ.</li>\n  <li>Tổ chức ánh sáng nhiều lớp: tổng thể, chức năng và nhấn điểm.</li>\n  <li>Ưu tiên vật liệu chạm êm, tông màu trung tính để tối ưu cảm giác nghỉ ngơi.</li>\n</ul>\n<p>Thiết kế master suite chuẩn giúp căn phòng sang trọng bền vững theo thời gian, không phụ thuộc quá nhiều vào xu hướng ngắn hạn.</p>','https://rhinelux.com/wp-content/uploads/2025/06/4_Interactive-LightMix-2.jpg','Thiết kế phòng ngủ master biệt thự tại Vinhomes','Tổng hợp giải pháp thiết kế phòng ngủ master biệt thự tại Vinhomes theo hướng sang trọng, tối ưu riêng tư và công năng.','2025-09-08 09:20:00',7,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(8,NULL,'Top mẫu thiết kế biệt thự Vinhomes Riverside sang trọng bậc nhất','top-mau-thiet-ke-biet-thu-vinhomes-riverside-sang-trong-bac-nhat','blog','Tuyển chọn các concept nổi bật tại Vinhomes Riverside với phong cách Modern Luxury, chú trọng chiều sâu vật liệu và trải nghiệm sống.','<p>Vinhomes Riverside là khu đô thị có mật độ biệt thự cao với nhiều phong cách sống khác nhau. Các mẫu thiết kế nổi bật đều có điểm chung: bố cục mạch lạc, vật liệu có chiều sâu và công năng rõ ràng.</p>\n<h3>Những tiêu chí tạo nên biệt thự “đẳng cấp nhưng thực dụng”</h3>\n<ul>\n  <li>Không gian khách – bếp mở, kết nối sân vườn bằng hệ kính lớn.</li>\n  <li>Vật liệu tự nhiên được dùng có điểm nhấn, tránh nặng nề thị giác.</li>\n  <li>Thiết kế theo nhu cầu sinh hoạt thật thay vì chạy theo hình ảnh.</li>\n</ul>','https://rhinelux.com/wp-content/uploads/2025/07/Khach.jpg','Top mẫu thiết kế biệt thự Vinhomes Riverside sang trọng','Tổng hợp các mẫu thiết kế biệt thự Vinhomes Riverside theo phong cách hiện đại, sang trọng và giàu trải nghiệm.','2025-10-22 08:30:00',8,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(9,1,'Biệt thự đơn lập Vinhomes Green Villas GV12-09: Sự chuyển tiếp tinh tế giữa ánh sáng và vật liệu','bt-don-lap-gv12-09-vinhomes-green-villas-2','project','GV12-09 tạo ấn tượng bằng nhịp chuyển mềm giữa đá xám, gỗ nâu và ánh sáng vàng dịu, mang lại trải nghiệm sống thư giãn và hiện đại.','<p>GV12-09 là phương án thiết kế đề cao cảm giác thư giãn trong không gian sống: các mảng nội thất lớn gọn ghẽ, ánh sáng được phân lớp và vật liệu trung tính có chiều sâu.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/GV12-09-3.jpg\" alt=\"Green Villas GV12-09\"></p>\n<p>Toàn bộ khu khách – bếp được xử lý đồng bộ về màu sắc và chi tiết hoàn thiện, giúp không gian thoáng, tinh tế và thuận tiện cho sinh hoạt gia đình.</p>','https://rhinelux.com/wp-content/uploads/2025/06/GV12-09-3.jpg','Biệt thự đơn lập Green Villas GV12-09','Thông tin dự án GV12-09 tại Green Villas với phong cách hiện đại, vật liệu trung tính và ánh sáng tinh tế.','2025-06-12 09:40:00',9,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(10,1,'Biệt thự đơn lập GV2-08A Vinhomes Green Villas: Á Đông hiện đại trong không gian sống mới','bt-don-lap-gv2-08a-vinhomes-green-villas','project','GV2-08A kết hợp tinh thần Á Đông qua vật liệu gỗ, bố cục đăng đối và lớp nền sáng hiện đại để tạo nên bản sắc sống riêng.','<p>GV2-08A là dự án thể hiện rõ cách kết hợp tinh thần Á Đông với ngôn ngữ thiết kế đương đại: giữ chất nền truyền thống nhưng xử lý nhẹ, sáng và tinh gọn.</p>\n<h3>Điểm nhấn thiết kế</h3>\n<p>Bàn ghế gỗ chân cao, bố cục đăng đối và tranh tường khổ lớn được đặt trên lớp nền tường sáng – rèm voan để tổng thể không nặng, vẫn giàu chiều sâu văn hóa.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2025/06/GV2-08.jpg\" alt=\"Green Villas GV2-08A\"></p>','https://rhinelux.com/wp-content/uploads/2025/06/GV2-08.jpg','Biệt thự đơn lập GV2-08A Vinhomes Green Villas','Dự án GV2-08A tại Green Villas với phong cách Á Đông hiện đại, tối ưu công năng và thẩm mỹ sống.','2025-06-13 09:45:00',10,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(11,1,'Biệt thự đơn lập DD2-02, Vinhomes Ocean Park','bt-don-lap-dd2-02-vinhomes-ocean-park','project','Bộ hồ sơ dự án DD2-02 nổi bật với bố cục ánh sáng rõ ràng, mảng vật liệu tự nhiên và giải pháp tổ chức không gian theo nhịp sống gia đình.','<p>Dự án DD2-02 tập trung vào trải nghiệm sống tiện nghi và bền vững: hệ giao thông trong nhà rõ ràng, phòng sinh hoạt mở và các mảng vật liệu có chiều sâu thị giác.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2024/12/03-KT.jpg\" alt=\"Biệt thự DD2-02\"></p>\n<p>Bộ ảnh thiết kế cho thấy sự liên tục giữa kiến trúc – nội thất – sân vườn, đảm bảo công năng sử dụng hàng ngày và cảm xúc thẩm mỹ trong từng khu vực.</p>','https://rhinelux.com/wp-content/uploads/2024/12/03-KT.jpg','Biệt thự đơn lập DD2-02 Vinhomes Ocean Park','Thông tin dự án biệt thự đơn lập DD2-02 tại Vinhomes Ocean Park với định hướng thiết kế – thi công nội thất hiện đại.','2024-12-14 09:00:00',5,1,'2026-04-16 01:19:40','2026-04-16 01:19:40'),(12,2,'Biệt thự đơn lập K5, KĐT Starlake','bt-don-lap-k5-kdt-starlake','project','Case study K5 Starlake nhấn mạnh sự cân bằng giữa tổ chức mặt bằng, ánh sáng và vật liệu để tối ưu chất lượng sống.','<p>Thiết kế K5 Starlake theo đuổi ngôn ngữ hiện đại tối giản, ưu tiên mặt bằng rõ nhịp, tỷ lệ nội thất chuẩn và tối đa ánh sáng tự nhiên trong các không gian sinh hoạt chính.</p>\n<p><img src=\"https://rhinelux.com/wp-content/uploads/2024/10/29.jpg\" alt=\"Biệt thự K5 Starlake\"></p>\n<p>Các mảng vật liệu lớn được xử lý đồng bộ, giảm chi tiết thừa, giúp tổng thể gọn và sang nhưng vẫn ấm áp cho nhịp sống gia đình.</p>','https://rhinelux.com/wp-content/uploads/2024/10/29.jpg','Biệt thự đơn lập K5 KĐT Starlake','Dự án biệt thự K5 Starlake với giải pháp tổ chức không gian, ánh sáng và vật liệu theo phong cách hiện đại.','2024-10-22 09:00:00',6,1,'2026-04-16 01:19:40','2026-04-16 01:19:40');
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contact_messages`
--

DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_page` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contact_messages`
--

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `menu_items`
--

DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_zone` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main',
  `parent_id` bigint unsigned DEFAULT NULL,
  `page_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `open_in_new_tab` tinyint(1) NOT NULL DEFAULT '0',
  `is_home_icon` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_items_is_active_sort_order_index` (`is_active`,`sort_order`),
  KEY `menu_items_menu_zone_sort_order_index` (`menu_zone`,`sort_order`),
  KEY `menu_items_parent_id_sort_order_index` (`parent_id`,`sort_order`),
  CONSTRAINT `menu_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu_items`
--

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,'Trang chủ','/','main',NULL,'home',1,1,0,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(2,'Vinhomes Ocean Park','/thiet-ke-biet-thu-vinhomes-ocean-park','main',NULL,'oceanpark',2,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(3,'Giới thiệu','/about-us','main',NULL,'about',3,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(4,'Blog','/blog','main',NULL,'blog',4,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(5,'Video','/video','main',NULL,'video',5,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(6,'Liên hệ','/lien-he','main',NULL,'contact',6,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(7,'Tổng quan','#tong-quan','about-us',NULL,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(8,'Giá trị & cam kết','#gia-tri','about-us',NULL,'about',2,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(9,'Đội ngũ & hồ sơ','#ceo','about-us',NULL,'about',3,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(10,'Sứ mệnh & Tầm nhìn','#su-menh','about-us',7,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(11,'Lợi thế cạnh tranh','#loi-the','about-us',8,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(12,'Hồ sơ năng lực','#ho-so','about-us',9,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27');
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',2),(4,'2019_12_14_000001_create_personal_access_tokens_table',2),(5,'2026_04_13_093905_create_pages_table',2),(6,'2026_04_13_093916_create_contact_messages_table',2),(7,'2026_04_14_023751_create_site_settings_table',2),(8,'2026_04_14_024020_create_menu_items_table',2),(9,'2026_04_14_103500_add_zone_and_parent_to_menu_items_table',2),(10,'2026_04_14_130000_create_projects_ecosystem_tables',2),(11,'2026_04_14_160000_add_thumbnail_click_action_to_project_detail_pages_table',2),(12,'2026_04_14_173000_create_blogs_table',2),(13,'2026_04_14_190500_add_project_id_to_blogs_table',2),(14,'2026_04_15_090000_add_display_zone_to_blogs_table',2),(15,'2026_04_15_120000_update_project_videos_table_for_global_video_management',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legacy_file` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'home',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Trang chủ','home','home','home','HOVI Việt Nam | Thiết Kế & Thi Công Cảnh Quan, Sân Vườn Cao Cấp','HOVI Việt Nam chuyên thiết kế, thi công cảnh quan và sân vườn cao cấp cho biệt thự, penthouse và khu đô thị.',1,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(2,'Giới thiệu','about-us','about-us','about','Giới Thiệu HOVI Việt Nam | Tầm Nhìn, Sứ Mệnh & Năng Lực','Khám phá HOVI Việt Nam, đơn vị thiết kế thi công cảnh quan và sân vườn cao cấp với quy trình rõ ràng.',2,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(3,'Liên hệ','lien-he','lien-he','contact','Liên Hệ HOVI Việt Nam | Đặt Lịch Tư Vấn Thiết Kế Cảnh Quan','Liên hệ HOVI Việt Nam để đặt lịch tư vấn thiết kế cảnh quan, sân vườn, biệt thự và penthouse.',3,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(4,'Thiết kế biệt thự Vinhomes Ocean Park','thiet-ke-biet-thu-vinhomes-ocean-park','thiet-ke-biet-thu-vinhomes-ocean-park','oceanpark','Thiết Kế Biệt Thự Vinhomes Ocean Park | Dự Án HOVI Việt Nam','Tổng hợp các dự án thiết kế biệt thự Vinhomes Ocean Park do HOVI Việt Nam thực hiện.',4,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(5,'Video','video','video','video','Video HOVI Việt Nam | Công trình thực tế & chia sẻ chuyên môn','Tổng hợp video công trình thực tế, hậu trường triển khai và kinh nghiệm thiết kế thi công từ HOVI Việt Nam.',5,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(6,'Blog','blog','blog','blog','Blog HOVI Việt Nam | Chia sẻ thiết kế cảnh quan','Chuyên mục Blog của HOVI Việt Nam: kiến thức thiết kế cảnh quan, kinh nghiệm thi công và xu hướng không gian sống.',6,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(7,'Biệt thự đơn lập M07-L14 Dương Nội','biet-thu-don-lap-m07-l14-dtm-duong-noi','biet-thu-don-lap-m07-l14-dtm-duong-noi','project','Biệt Thự Đơn Lập M07-L14 ĐTM Dương Nội | Dự Án HOVI Việt Nam','Chi tiết dự án biệt thự đơn lập M07-L14 ĐTM Dương Nội của HOVI Việt Nam với hình ảnh phối cảnh.',7,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(8,'Đăng ký dịch vụ','dang-ky-dich-vu','dang-ky-dich-vu','contact','Đăng Ký Dịch Vụ HOVI Việt Nam | Tư Vấn Thiết Kế Thi Công Biệt Thự','Đăng ký dịch vụ thiết kế thi công biệt thự cao cấp tại HOVI Việt Nam. Để lại thông tin để đội ngũ tư vấn liên hệ sớm nhất.',8,1,'2026-04-15 04:15:26','2026-04-15 04:15:26');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_resets`
--

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `personal_access_tokens`
--

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_blogs`
--

DROP TABLE IF EXISTS `project_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_blogs_slug_unique` (`slug`),
  KEY `project_blogs_project_id_sort_order_index` (`project_id`,`sort_order`),
  CONSTRAINT `project_blogs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_blogs`
--

LOCK TABLES `project_blogs` WRITE;
/*!40000 ALTER TABLE `project_blogs` DISABLE KEYS */;
INSERT INTO `project_blogs` VALUES (1,1,'Top 10 mẫu sân vườn biệt thự tại Ocean Park','top-10-mau-san-vuon-biet-thu-ocean-park','Gợi ý các mẫu sân vườn đẹp theo diện tích và phong cách kiến trúc tại Vinhomes Ocean Park.','Bài viết phân tích bố cục sân vườn, nhóm cây phù hợp và kinh nghiệm triển khai thực tế.','/theme/assets/hovi/gallery/hovi-036.jpg','/biet-thu-don-lap-m07-l14-dtm-duong-noi','2026-04-09 01:19:39',1,1,'2026-04-15 04:15:27','2026-04-16 01:19:39'),(2,1,'Checklist thi công cảnh quan đúng kỹ thuật','checklist-thi-cong-canh-quan-dung-ky-thuat','Những điểm cần kiểm soát khi thi công để đảm bảo tiến độ và chất lượng bàn giao.','Từ xử lý nền, chống thấm, tưới tự động đến kế hoạch bảo trì sau bàn giao đều cần tiêu chuẩn rõ ràng.','/theme/assets/hovi/gallery/hovi-037.jpg','/thiet-ke-biet-thu-vinhomes-ocean-park','2026-04-13 01:19:39',2,1,'2026-04-15 04:15:27','2026-04-16 01:19:39'),(3,2,'Mockup blog: 5 lỗi thường gặp khi làm sân vườn','mockup-blog-5-loi-thuong-gap-khi-lam-san-vuon','Bài mẫu để test các trường tiêu đề, mô tả và link đích.','Nội dung mẫu có thể thay bằng bài thật bất kỳ lúc nào.','/theme/assets/hovi/gallery/hovi-029.jpg','/thiet-ke-san-vuon-biet-thu-starlake-mockup','2026-04-15 01:19:39',1,1,'2026-04-15 04:15:27','2026-04-16 01:19:40');
/*!40000 ALTER TABLE `project_blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_detail_pages`
--

DROP TABLE IF EXISTS `project_detail_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_detail_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_click_action` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link',
  `gallery_images` longtext COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_detail_pages_slug_unique` (`slug`),
  KEY `project_detail_pages_project_id_sort_order_index` (`project_id`,`sort_order`),
  CONSTRAINT `project_detail_pages_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_detail_pages`
--

LOCK TABLES `project_detail_pages` WRITE;
/*!40000 ALTER TABLE `project_detail_pages` DISABLE KEYS */;
INSERT INTO `project_detail_pages` VALUES (1,1,'Biệt thự đơn lập M07-L14 ĐTM Dương Nội','biet-thu-don-lap-m07-l14-dtm-duong-noi','Hồ sơ thiết kế - thi công cảnh quan cho biệt thự đơn lập, tối ưu công năng và thẩm mỹ.','Thiết kế chú trọng bố cục xanh đa lớp, lối dạo kết nối mềm và khu vực thư giãn ngoài trời cho gia đình đa thế hệ.','/theme/assets/hovi/gallery/hovi-035.jpg','link','[\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-035.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-036.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-037.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-038.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-039.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-040.jpg\"]',1,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(2,1,'Biệt thự đơn lập NT17-10 Vinhomes Ocean Park','biet-thu-don-lap-nt17-10-vinhomes-ocean-park','Phương án cảnh quan sân vườn tích hợp hệ đèn và mảng xanh theo phong cách resort.','Hệ thống cây tầng cao - trung - thấp được phối theo nhịp sinh trưởng để cảnh quan bền đẹp quanh năm.','/theme/assets/hovi/gallery/hovi-041.jpg','link','[\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-041.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-042.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-043.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-044.jpg\"]',2,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(3,2,'Biệt thự song lập khu H Starlake','biet-thu-song-lap-khu-h-starlake-mockup','Mẫu trang chi tiết với gallery ảnh để kiểm thử flow nhập liệu.','Dữ liệu mockup: bạn có thể chỉnh sửa tự do để làm mẫu đào tạo nội bộ.','/theme/assets/hovi/gallery/hovi-026.jpg','link','[\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-026.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-027.jpg\",\"\\/theme\\/assets\\/hovi\\/gallery\\/hovi-028.jpg\"]',1,1,'2026-04-15 04:15:27','2026-04-15 04:15:27');
/*!40000 ALTER TABLE `project_detail_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_videos`
--

DROP TABLE IF EXISTS `project_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_videos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `content` longtext COLLATE utf8mb4_unicode_ci,
  `display_zone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_videos_slug_unique` (`slug`),
  KEY `project_videos_project_id_sort_order_index` (`project_id`,`sort_order`),
  KEY `project_videos_display_zone_index` (`display_zone`),
  CONSTRAINT `project_videos_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `project_videos`
--

LOCK TABLES `project_videos` WRITE;
/*!40000 ALTER TABLE `project_videos` DISABLE KEYS */;
INSERT INTO `project_videos` VALUES (4,1,'Tour nội thất biệt thự Green Villas GV11-02 | Modern Luxury','tour-noi-that-biet-thu-green-villas-gv11-02-modern-luxury','https://www.youtube.com/watch?v=M7lc1UVf-VE','https://rhinelux.com/wp-content/uploads/2025/06/GV11-02.jpg','Toàn cảnh không gian khách - bếp - thông tầng của dự án GV11-02 theo tinh thần Modern Luxury.','<p>Video ghi lại các lớp không gian chính của biệt thự GV11-02: phòng khách, khu bếp và trục thông tầng.</p>\n<p>Tập trung vào nhịp chuyển vật liệu đá - gỗ - kim loại cùng cách xử lý ánh sáng tạo cảm giác sang trọng nhưng vẫn ấm áp.</p>','all','Tour nội thất biệt thự Green Villas GV11-02','Video tour nội thất biệt thự GV11-02 tại Green Villas theo phong cách Modern Luxury.','2025-06-20 11:00:00',1,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(5,1,'Video thực tế GV7-06: không gian nâu gỗ cổ điển sang trọng','video-thuc-te-gv7-06-khong-gian-nau-go-co-dien-sang-trong','https://www.youtube.com/watch?v=dQw4w9WgXcQ','https://rhinelux.com/wp-content/uploads/2025/06/GV7-06-2.jpg','Hành trình hoàn thiện dự án GV7-06 với chất liệu gỗ trầm, ánh sáng vàng và chi tiết nhấn tinh tế.','<p>Trong video này, đội ngũ chia sẻ quá trình hoàn thiện vật liệu và kiểm soát tỷ lệ nội thất cho không gian nâu gỗ.</p>\n<p>Các điểm nhấn về đèn và phụ kiện được tiết chế để giữ tổng thể thanh lịch, không nặng nề.</p>','video','Video thực tế dự án GV7-06 Green Villas','Cập nhật video công trình GV7-06 với phong cách nâu gỗ cổ điển sang trọng.','2025-06-18 09:30:00',2,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(6,1,'Behind the scenes: hiệu chỉnh 3D Louis City Hoàng Mai','behind-the-scenes-hieu-chinh-3d-louis-city-hoang-mai','https://www.youtube.com/watch?v=oHg5SJYRHA0','https://rhinelux.com/wp-content/uploads/2025/07/ARCHITECTURE-9.jpg','Quy trình rà soát công năng, vật liệu và điểm nhìn trước khi chốt phương án thi công.','<p>Video tập trung vào giai đoạn hiệu chỉnh 3D: cân lại tỷ lệ, vật liệu và chi tiết kỹ thuật trước thi công.</p>\n<p>Đây là bước giúp giảm rủi ro phát sinh và đảm bảo trải nghiệm sử dụng thực tế của gia chủ.</p>','video','Behind the scenes hiệu chỉnh 3D biệt thự Louis City','Khám phá quy trình hiệu chỉnh 3D cho biệt thự Louis City trước khi triển khai thi công.','2025-07-22 10:00:00',3,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(8,1,'Walkthrough DD2-02 Ocean Park: ánh sáng và vật liệu','walkthrough-dd2-02-ocean-park-anh-sang-va-vat-lieu','https://www.youtube.com/watch?v=9bZkp7q19f0','https://rhinelux.com/wp-content/uploads/2024/12/03-KT.jpg','Review công trình DD2-02 với góc nhìn về tổ chức mặt bằng và xử lý ánh sáng nội thất.','<p>Video cho thấy cách bố cục không gian và lựa chọn vật liệu giúp công trình vừa sang trọng vừa tiện dụng.</p>\n<p>Các mảng chính được xử lý đồng bộ nhằm tạo cảm giác liền mạch giữa kiến trúc và nội thất.</p>','project','Walkthrough DD2-02 Vinhomes Ocean Park','Video review dự án DD2-02 tại Ocean Park với điểm nhấn về ánh sáng và vật liệu.','2024-12-15 08:45:00',5,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(9,1,'GV12-09 Green Villas: nhịp chuyển mềm giữa đá và gỗ','gv12-09-green-villas-nhip-chuyen-mem-giua-da-va-go','https://www.youtube.com/watch?v=kXYiU_JCYtU','https://rhinelux.com/wp-content/uploads/2025/06/GV12-09-3.jpg','Video cận cảnh các lớp vật liệu và ánh sáng của dự án GV12-09.','<p>Nội dung tập trung vào cách phối vật liệu trung tính để giữ sự nhẹ nhàng và chiều sâu thị giác.</p>\n<p>Giải pháp chiếu sáng được chia lớp, tăng trải nghiệm thư giãn cho khu khách - bếp.</p>','all','Video GV12-09 Green Villas','Khám phá video dự án GV12-09 với nhịp chuyển vật liệu tinh tế.','2025-06-13 09:20:00',6,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(10,1,'GV2-08A Green Villas: tinh thần Á Đông hiện đại','gv2-08a-green-villas-tinh-than-a-dong-hien-dai','https://www.youtube.com/watch?v=3JZ_D3ELwOQ','https://rhinelux.com/wp-content/uploads/2025/06/GV2-08.jpg','Giới thiệu ngôn ngữ thiết kế Á Đông hiện đại trong không gian biệt thự GV2-08A.','<p>Video thể hiện cách kết hợp chi tiết gỗ và bố cục đăng đối với nền sáng hiện đại.</p>\n<p>Tổng thể mang đến cảm giác trang nhã, gần gũi và phù hợp sinh hoạt gia đình.</p>','video','Video GV2-08A Green Villas','Video dự án GV2-08A với phong cách Á Đông hiện đại và bố cục tinh gọn.','2025-06-14 09:10:00',7,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(11,2,'Mockup Starlake: kiểm thử luồng quản trị video trong CMS','mockup-starlake-kiem-thu-luong-quan-tri-video-trong-cms','https://www.youtube.com/watch?v=L_jWHffIx5E','/theme/assets/hovi/gallery/hovi-030.jpg','Video mẫu phục vụ đào tạo thao tác quản trị nội dung video trong hệ thống.','<p>Video mockup giúp đội vận hành kiểm tra toàn bộ luồng nhập liệu: tạo mới, chỉnh sửa, xuất bản và hiển thị frontend.</p>\n<p>Nội dung có thể thay thế linh hoạt theo nhu cầu đào tạo nội bộ.</p>','project','Mockup Starlake: kiểm thử quản trị video','Video mẫu phục vụ kiểm thử và đào tạo quy trình quản trị video trong CMS.','2026-01-10 08:30:00',8,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(12,1,'Thi công hoàn thiện phòng khách biệt thự: checklist hiện trường','thi-cong-hoan-thien-phong-khach-biet-thu-checklist-hien-truong','https://www.youtube.com/watch?v=fLexgOxsZu0','https://rhinelux.com/wp-content/uploads/2025/06/DSC09077-copy.jpg','Checklist thực tế để kiểm soát chất lượng thi công khu khách theo đúng hồ sơ thiết kế.','<p>Video chia sẻ các điểm cần kiểm tra khi hoàn thiện phòng khách: cao độ, khe mạch, ánh sáng và bề mặt vật liệu.</p>\n<p>Áp dụng checklist giúp giảm lỗi phát sinh trước giai đoạn bàn giao.</p>','video','Checklist thi công hoàn thiện phòng khách biệt thự','Video checklist hiện trường cho hạng mục phòng khách biệt thự.','2025-06-16 10:10:00',9,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(13,1,'Layout Vinhomes Cổ Loa: giải thích tư duy bố trí không gian','layout-vinhomes-co-loa-giai-thich-tu-duy-bo-tri-khong-gian','https://www.youtube.com/watch?v=e-ORhEE9VVg','https://rhinelux.com/wp-content/uploads/2026/03/CAH_TANG-1-3.jpg','Video chia sẻ tư duy tổ chức layout cho biệt thự song lập và liền kề tại Vinhomes Cổ Loa.','<p>Nội dung tập trung vào cách tổ chức giao thông nội bộ, điểm nhìn và phân lớp công năng theo nhu cầu sử dụng thực tế.</p>\n<p>Đây là tài liệu tham khảo hữu ích cho chủ nhà ở giai đoạn chuẩn bị thiết kế nội thất.</p>','all','Layout Vinhomes Cổ Loa: tư duy bố trí không gian','Video phân tích tư duy bố trí không gian cho các mẫu biệt thự tại Vinhomes Cổ Loa.','2026-03-16 09:05:00',10,1,'2026-04-15 04:15:28','2026-04-15 04:15:28'),(23,2,'Nhật ký công trình K5 Starlake: từ bản vẽ tới không gian thật','nhat-ky-cong-trinh-k5-starlake-tu-ban-ve-toi-khong-gian-that','https://www.youtube.com/watch?v=FTQbiNvZqaY','https://rhinelux.com/wp-content/uploads/2024/10/29.jpg','Theo dõi tiến độ hoàn thiện công trình K5 Starlake với các mốc thi công quan trọng.','<p>Tư liệu thực địa ghi lại tiến độ triển khai theo từng hạng mục chính: thô, hoàn thiện và bàn giao.</p>\n<p>Video nhấn vào việc kiểm soát chi tiết để đảm bảo đúng bản thiết kế ban đầu.</p>','project','Nhật ký công trình K5 Starlake','Video hậu trường thi công K5 Starlake từ bản vẽ đến không gian sống thực tế.','2024-10-23 09:00:00',4,1,'2026-04-15 09:04:03','2026-04-15 09:04:03');
/*!40000 ALTER TABLE `project_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` text COLLATE utf8mb4_unicode_ci,
  `intro` longtext COLLATE utf8mb4_unicode_ci,
  `cover_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (1,'Thiết kế biệt thự Vinhomes Ocean Park','thiet-ke-biet-thu-vinhomes-ocean-park','Tổng hợp các dự án biệt thự do HOVI triển khai tại Ocean Park với hình ảnh thực tế, video và bài viết tư vấn.','Dự án tập trung vào giải pháp cảnh quan cao cấp, tối ưu không gian xanh và trải nghiệm sống cho từng gia đình.','/theme/assets/hovi/gallery/hovi-024.jpg','Thiết kế biệt thự Vinhomes Ocean Park | Dự án HOVI Việt Nam','Dự án thực tế tại Vinhomes Ocean Park: trang chi tiết, blog chuyên sâu và video thực chiến từ HOVI Việt Nam.',1,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(2,'Thiết kế sân vườn biệt thự Starlake (Mockup)','thiet-ke-san-vuon-biet-thu-starlake-mockup','Dự án mẫu để đội content luyện thao tác quản trị: thêm trang chi tiết, blog và video.','Dùng cho mục đích demo giao diện quản trị và quy trình cập nhật nội dung theo chuẩn SEO.','/theme/assets/hovi/gallery/hovi-025.jpg','Thiết kế sân vườn biệt thự Starlake (Mockup) | HOVI Việt Nam','Dự án mockup phục vụ huấn luyện thao tác quản trị nội dung dự án trong CMS.',2,1,'2026-04-15 04:15:27','2026-04-15 04:15:27');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `site_settings`
--

DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `site_settings`
--

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'site_name','HOVI Việt Nam','2026-04-15 04:15:26','2026-04-15 04:15:26'),(2,'site_tagline','Thiết kế và thi công cảnh quan, sân vườn cao cấp cho biệt thự và penthouse.','2026-04-15 04:15:26','2026-04-15 04:15:26'),(3,'header_logo','/theme/logoMenuRight1.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(4,'footer_logo','/theme/logofooter.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(5,'favicon','/theme/logohome.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(6,'seo_default_title','HOVI Việt Nam | Thiết Kế & Thi Công Cảnh Quan, Sân Vườn Cao Cấp','2026-04-15 04:15:26','2026-04-15 04:15:26'),(7,'seo_default_description','HOVI Việt Nam chuyên thiết kế, thi công cảnh quan và sân vườn cao cấp cho biệt thự, penthouse và khu đô thị.','2026-04-15 04:15:27','2026-04-15 04:15:27'),(8,'seo_keywords','thiết kế cảnh quan, thi công sân vườn, biệt thự, penthouse, HOVI Việt Nam','2026-04-15 04:15:27','2026-04-16 01:19:39'),(9,'seo_robots','index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1','2026-04-15 04:15:27','2026-04-15 04:15:27'),(10,'seo_canonical_base','https://hovi-content.annamloi.com','2026-04-15 04:15:27','2026-04-15 04:15:27'),(11,'seo_og_image','/theme/logohome.png','2026-04-15 04:15:27','2026-04-15 04:15:27'),(12,'footer_company_name','CÔNG TY TNHH HOVI VIỆT NAM','2026-04-15 04:15:27','2026-04-15 04:15:27'),(13,'footer_tax_code','2301198445','2026-04-15 04:15:27','2026-04-15 04:15:27'),(14,'footer_address','BT6 KĐT Việt Hưng, Long Biên, Hà Nội','2026-04-15 04:15:27','2026-04-15 04:15:27'),(15,'footer_website','https://www.hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(16,'footer_email','hovivietnam99@gmail.com','2026-04-15 04:15:27','2026-04-15 04:15:27'),(17,'footer_phone','0988991635','2026-04-15 04:15:27','2026-04-16 01:19:39'),(18,'footer_copyright','© HOVI Việt Nam','2026-04-15 04:15:27','2026-04-15 04:15:27'),(19,'social_facebook','https://www.hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(20,'social_tiktok','https://www.hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(21,'social_youtube','https://www.hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(22,'social_messenger','https://www.hovi.com.vn/','2026-04-15 04:15:27','2026-04-15 04:15:27'),(23,'social_zalo','https://zalo.me/0988991635','2026-04-15 04:15:27','2026-04-15 04:15:27'),(24,'about_content','{\"hero\":{\"enabled\":true,\"eyebrow\":\"About Us\",\"title\":\"HOVI VIỆT NAM - THIẾT KẾ & THI CÔNG CẢNH QUAN, SÂN VƯỜN CAO CẤP\",\"description\":\"Thành lập từ năm 2021, HOVI Việt Nam mang sứ mệnh đưa thiên nhiên vào không gian sống một cách nghệ thuật, tinh tế và bền vững. Chúng tôi tập trung vào các giải pháp cảnh quan cá nhân hóa cho biệt thự, penthouse và không gian dịch vụ.\",\"image\":\"/theme/assets/hovi/about-hero.png\",\"image_alt\":\"Cảnh quan sân vườn HOVI Việt Nam\"},\"mission\":{\"enabled\":true,\"title\":\"Sứ mệnh\",\"description\":\"Kiến tạo những không gian xanh “độc bản”, kết hợp thẩm mỹ và công năng để nâng cao chất lượng sống, sức khỏe tinh thần và giá trị lâu dài cho từng công trình.\",\"image\":\"/theme/assets/hovi/about-mission.png\",\"image_alt\":\"Không gian xanh biệt thự - HOVI Việt Nam\"},\"vision\":{\"enabled\":true,\"title\":\"Tầm nhìn\",\"description\":\"Trở thành đơn vị dẫn đầu trong lĩnh vực thiết kế cảnh quan thông minh (Smart Landscape) tại Việt Nam, kết hợp hài hòa giữa kiến trúc hiện đại và hệ sinh thái tự nhiên.\",\"image\":\"/theme/assets/hovi/about-vision.png\",\"image_alt\":\"Thiết kế sân vườn phong cách hiện đại\"},\"inspiration\":{\"enabled\":true,\"title\":\"Cảm hứng thương hiệu\",\"subtitle\":\"HOVI - Garden Flowers\",\"description\":\"HOVI theo đuổi triết lý “Tinh tế - Chu đáo, Sáng tạo - Đam mê”, mang tinh thần thủ công chỉn chu vào từng chi tiết cảnh quan để mỗi không gian đều có bản sắc riêng và giá trị sử dụng bền vững.\",\"image\":\"/theme/assets/hovi/about-inspiration.png\",\"image_alt\":\"Cảm hứng cảnh quan bonsai nghệ thuật\"},\"definition\":{\"enabled\":true,\"title\":\"HOVI: Không gian xanh cho phong cách sống hiện đại\",\"description\":\"Chúng tôi tin rằng sân vườn không chỉ là phần “trang trí”, mà là lá phổi xanh của ngôi nhà và là nơi tái tạo năng lượng mỗi ngày. HOVI ứng dụng thiết kế 3D trực quan, thi công đúng chuẩn và bảo hành dài hạn để đảm bảo chất lượng.\"},\"core\":{\"enabled\":true,\"heading\":\"Giá trị cốt lõi\",\"items\":[{\"title\":\"Tinh tế\",\"description\":\"Mỗi chi tiết cảnh quan được cân chỉnh hài hòa theo kiến trúc, công năng và trải nghiệm sử dụng thực tế.\",\"image\":\"/theme/assets/hovi/about-core-1.jpg\",\"image_alt\":\"Tinh tế\"},{\"title\":\"Chu đáo\",\"description\":\"Lắng nghe kỹ nhu cầu khách hàng, đồng hành xuyên suốt từ tư vấn, thiết kế đến chăm sóc sau bàn giao.\",\"image\":\"/theme/assets/hovi/about-core-2.jpg\",\"image_alt\":\"Chu đáo\"},{\"title\":\"Sáng tạo\",\"description\":\"Liên tục cập nhật xu hướng và công nghệ để mang đến giải pháp thiết kế độc bản cho từng công trình.\",\"image\":\"/theme/assets/hovi/about-core-3.jpg\",\"image_alt\":\"Sáng tạo\"},{\"title\":\"Đam mê\",\"description\":\"Đội ngũ HOVI đặt trọn tâm huyết vào từng dự án để mỗi khu vườn đều có chiều sâu cảm xúc riêng.\",\"image\":\"/theme/assets/hovi/about-core-4.jpg\",\"image_alt\":\"Đam mê\"},{\"title\":\"Chuyên nghiệp\",\"description\":\"Quy trình làm việc rõ ràng, vật tư minh bạch và thi công theo tiêu chuẩn kỹ thuật đã cam kết.\",\"image\":\"/theme/assets/hovi/about-core-5.jpg\",\"image_alt\":\"Chuyên nghiệp\"},{\"title\":\"Bền vững\",\"description\":\"Ưu tiên giải pháp xanh, tối ưu bảo trì và bảo hành dài hạn để cảnh quan giữ được vẻ đẹp lâu dài.\",\"image\":\"/theme/assets/hovi/about-core-6.jpg\",\"image_alt\":\"Bền vững\"}]},\"manifesto\":{\"enabled\":true,\"heading\":\"Cam kết thương hiệu\",\"items\":[{\"quote\":\"“Mỗi bản vẽ là một câu chuyện riêng, phù hợp phong cách và phong thủy của gia chủ.”\",\"image\":\"/theme/assets/hovi/about-manifesto-1.jpg\",\"image_alt\":\"Cam kết 1\"},{\"quote\":\"“Thiết kế trực quan bằng 3D để khách hàng nhìn thấy rõ không gian trước khi thi công.”\",\"image\":\"/theme/assets/hovi/about-manifesto-2.jpg\",\"image_alt\":\"Cam kết 2\"},{\"quote\":\"“Thi công đúng tiến độ, đúng chủng loại vật liệu và đồng hành bảo hành dài hạn.”\",\"image\":\"/theme/assets/hovi/about-manifesto-3.jpg\",\"image_alt\":\"Cam kết 3\"}]},\"advantages\":{\"enabled\":true,\"title\":\"Lợi thế cạnh tranh\",\"image\":\"/theme/assets/hovi/about-advantages.png\",\"image_alt\":\"Lợi thế cạnh tranh HOVI Việt Nam\",\"items\":[{\"title\":\"Cá nhân hóa thiết kế\",\"description\":\"mỗi phương án được xây dựng theo gu sống, ngân sách và hiện trạng thực tế.\"},{\"title\":\"Ứng dụng công nghệ\",\"description\":\"mô phỏng 3D trực quan giúp chốt phương án nhanh và giảm sai lệch thi công.\"},{\"title\":\"Thi công chuẩn kỹ thuật\",\"description\":\"quy trình chặt chẽ, kiểm soát vật tư và chất lượng theo từng hạng mục.\"},{\"title\":\"Đúng tiến độ\",\"description\":\"phối hợp đồng bộ giữa thiết kế, cung ứng và thi công để bàn giao đúng cam kết.\"},{\"title\":\"Hậu mãi rõ ràng\",\"description\":\"bảo dưỡng định kỳ và bảo hành dài hạn để cảnh quan luôn đẹp theo thời gian.\"}]},\"ceo\":{\"enabled\":true,\"eyebrow\":\"Thông điệp từ HOVI Việt Nam\",\"title\":\"Đội ngũ sáng lập\",\"description_1\":\"“Trong nhịp sống hiện đại, sân vườn không chỉ là khoảng xanh quanh nhà mà còn là nơi tái tạo năng lượng và thể hiện phong cách sống của gia chủ. Đó là lý do HOVI theo đuổi các giải pháp cảnh quan vừa đẹp, vừa bền vững.”\",\"description_2\":\"Chúng tôi trân trọng mọi cơ hội hợp tác và tin rằng sự đồng hành giữa HOVI với đối tác, khách hàng sẽ tạo nên những công trình giàu cảm hứng, nâng cao giá trị thương hiệu và chất lượng sống.\",\"image\":\"/theme/assets/hovi/about-ceo.png\",\"image_alt\":\"Đội ngũ sáng lập HOVI Việt Nam\"},\"capacity\":{\"enabled\":true,\"heading\":\"Hồ sơ năng lực\",\"lead\":\"HOVI cung cấp dịch vụ thiết kế - thi công sân vườn biệt thự, tiểu cảnh hồ cá koi, trang trí ban công/penthouse và các gói decor sự kiện, set up hoa theo yêu cầu cho không gian cao cấp.\",\"stats\":[{\"value\":\"Since 2021\",\"label\":\"Khởi tạo thương hiệu\"},{\"value\":\"05\",\"label\":\"Bước quy trình chuẩn\"},{\"value\":\"04\",\"label\":\"Nhóm sản phẩm mẫu\"},{\"value\":\"Dài hạn\",\"label\":\"Bảo hành & chăm sóc\"}],\"action_1_label\":\"NHẬN HỒ SƠ NĂNG LỰC\",\"action_1_url\":\"mailto:hovivietnam99@gmail.com\",\"action_2_label\":\"ĐẶT LỊCH TƯ VẤN\",\"action_2_url\":\"/lien-he\"}}','2026-04-15 04:15:27','2026-04-15 04:15:27'),(25,'home_content','{\"hero\":{\"background_image\":\"/theme/assets/hero.jpg\",\"scroll_target\":\"#projects-1\"},\"profile\":{\"background_image\":\"/theme/assets/hovi/gallery/hovi-060.jpg\",\"eyebrow\":\"Hồ sơ năng lực\",\"title\":\"Không gian được thiết kế như một tuyên ngôn sống\",\"description_1\":\"Thấu hiểu rằng mỗi công trình là hiện thân của những ước mơ và cá tính riêng của khách hàng, HOVI VIỆT NAM luôn đặt sự tận tâm với nghề và nỗ lực sáng tạo lên hàng đầu để mang tới những không gian kết hợp hài hòa giữa tầm nhìn nghệ thuật của kiến trúc sư và nhu cầu sử dụng thực tế.\",\"description_2\":\"Với HOVI VIỆT NAM, hạnh phúc lớn nhất là được đồng hành cùng khách hàng trên hành trình kiến tạo tổ ấm. Chính sự tin tưởng đó là động lực để đội ngũ không ngừng hoàn thiện, phát triển và nâng chuẩn dịch vụ.\",\"button_label\":\"Catalogue HOVI VIỆT NAM\",\"button_url\":\"#footer\",\"slider_images\":[\"/theme/assets/hovi/gallery/hovi-014.jpg\",\"/theme/assets/hovi/gallery/hovi-015.jpg\",\"/theme/assets/hovi/gallery/hovi-016.jpg\",\"/theme/assets/hovi/gallery/hovi-017.jpg\",\"/theme/assets/hovi/gallery/hovi-018.jpg\",\"/theme/assets/hovi/gallery/hovi-019.jpg\"]},\"about\":{\"title\":\"Về HOVI VIỆT NAM\",\"description\":\"Kể từ khi thành lập vào năm 2015, chúng tôi không ngừng khẳng định vị thế là một trong những đơn vị mang đến cho khách hàng giải pháp nâng tầm không gian toàn diện hàng đầu, từ khâu thiết kế và thi công kiến trúc đến sản xuất và lắp đặt nội thất. Trong một thị trường biệt thự đầy cạnh tranh, HOVI VIỆT NAM được tin - yêu không chỉ bởi mức độ xuất sắc của sản phẩm mà còn bởi dịch vụ tư vấn và đồng hành cùng khách hàng sau khi tiếp nhận yêu cầu.\",\"stats\":[{\"value\":\"10+\",\"label\":\"Năm kinh nghiệm\"},{\"value\":\"80\",\"label\":\"Nhân sự\"},{\"value\":\"100\",\"label\":\"Khách hàng\"},{\"value\":\"100+\",\"label\":\"Dự án thi công\"}],\"cta_label\":\"XEM THÊM\",\"cta_url\":\"/about-us\",\"team_image\":\"/theme/assets/hovi/gallery/hovi-060.jpg\"},\"footer_cta\":{\"consult\":{\"title\":\"ĐẶT LỊCH TƯ VẤN\",\"button_label\":\"Đặt lịch\",\"button_url\":\"/dang-ky-dich-vu\",\"background_image\":\"/theme/assets/hovi/gallery/hovi-001.jpg\"},\"partner\":{\"title\":\"TRỞ THÀNH ĐỐI TÁC HOVI VIỆT NAM\",\"button_label\":\"Tham gia\",\"button_url\":\"/lien-he\",\"background_image\":\"/theme/assets/hovi/gallery/hovi-055.jpg\"}},\"project_highlights\":{\"mode\":\"auto\",\"items\":[],\"auto_excluded_detail_page_ids\":[]}}','2026-04-15 04:15:27','2026-04-15 09:04:03');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'HOVI Admin','admin@hovi.local',NULL,'$2y$10$HzFLFlpvWdFT6urDfSVHB.2e8LsCYzptGejaR5zHxe4h8wBqi9h6S',NULL,'2026-04-15 04:15:26','2026-04-16 01:19:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-16  1:51:43
