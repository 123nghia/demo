
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned DEFAULT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_zone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogs_slug_unique` (`slug`),
  KEY `blogs_is_published_sort_order_index` (`is_published`,`sort_order`),
  KEY `blogs_published_at_index` (`published_at`),
  KEY `blogs_project_id_is_published_index` (`project_id`,`is_published`),
  KEY `blogs_visibility_zone_published_idx` (`is_published`,`display_zone`,`published_at`),
  CONSTRAINT `blogs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contact_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contact_messages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `source_page` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(30) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_read` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contact_messages` WRITE;
/*!40000 ALTER TABLE `contact_messages` DISABLE KEYS */;
INSERT INTO `contact_messages` VALUES (1,'lien-he','13','+84383338840','nghiait06@gmail.com',NULL,'13131',0,'2026-04-17 01:41:40','2026-04-17 01:41:40'),(2,'dang-ky-dich-vu','13','+84383338840','nghiait06@gmail.com','31','131',0,'2026-04-17 01:42:07','2026-04-17 01:42:07');
/*!40000 ALTER TABLE `contact_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `menu_zone` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'main',
  `parent_id` bigint unsigned DEFAULT NULL,
  `page_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `open_in_new_tab` tinyint(1) NOT NULL DEFAULT '0',
  `is_home_icon` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_items_is_active_sort_order_index` (`is_active`,`sort_order`),
  KEY `menu_items_menu_zone_sort_order_index` (`menu_zone`,`sort_order`),
  KEY `menu_items_parent_id_sort_order_index` (`parent_id`,`sort_order`),
  CONSTRAINT `menu_items_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `menu_items` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,'Trang chủ','/','main',NULL,'home',1,1,0,1,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(3,'Giới thiệu','/about-us','main',NULL,'about',3,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(4,'Blog','/blog','main',NULL,'blog',4,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(5,'Video','/video','main',NULL,'video',5,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(6,'Liên hệ','/lien-he','main',NULL,'contact',6,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(7,'Tổng quan','#tong-quan','about-us',NULL,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(8,'Giá trị & cam kết','#gia-tri','about-us',NULL,'about',2,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(9,'Đội ngũ & hồ sơ','#ceo','about-us',NULL,'about',3,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(10,'Sứ mệnh & Tầm nhìn','#su-menh','about-us',7,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(11,'Lợi thế cạnh tranh','#loi-the','about-us',8,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27'),(12,'Hồ sơ năng lực','#ho-so','about-us',9,'about',1,1,0,0,'2026-04-15 04:15:27','2026-04-15 04:15:27');
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2019_08_19_000000_create_failed_jobs_table',2),(4,'2019_12_14_000001_create_personal_access_tokens_table',2),(5,'2026_04_13_093905_create_pages_table',2),(6,'2026_04_13_093916_create_contact_messages_table',2),(7,'2026_04_14_023751_create_site_settings_table',2),(8,'2026_04_14_024020_create_menu_items_table',2),(9,'2026_04_14_103500_add_zone_and_parent_to_menu_items_table',2),(10,'2026_04_14_130000_create_projects_ecosystem_tables',2),(11,'2026_04_14_160000_add_thumbnail_click_action_to_project_detail_pages_table',2),(12,'2026_04_14_173000_create_blogs_table',2),(13,'2026_04_14_190500_add_project_id_to_blogs_table',2),(14,'2026_04_15_090000_add_display_zone_to_blogs_table',2),(15,'2026_04_15_120000_update_project_videos_table_for_global_video_management',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `legacy_file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `page_key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'home',
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `pages_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (1,'Trang chủ','home','home','home','HOVI Việt Nam | Thiết Kế & Thi Công Cảnh Quan, Sân Vườn Cao Cấp','HOVI Việt Nam chuyên thiết kế, thi công cảnh quan và sân vườn cao cấp cho biệt thự, penthouse và khu đô thị.',1,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(2,'Giới thiệu','about-us','about-us','about','Giới Thiệu HOVI Việt Nam | Tầm Nhìn, Sứ Mệnh & Năng Lực','Khám phá HOVI Việt Nam, đơn vị thiết kế thi công cảnh quan và sân vườn cao cấp với quy trình rõ ràng.',2,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(3,'Liên hệ','lien-he','lien-he','contact','Liên Hệ HOVI Việt Nam | Đặt Lịch Tư Vấn Thiết Kế Cảnh Quan','Liên hệ HOVI Việt Nam để đặt lịch tư vấn thiết kế cảnh quan, sân vườn, biệt thự và penthouse.',3,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(4,'Thiết kế biệt thự Vinhomes Ocean Park','thiet-ke-biet-thu-vinhomes-ocean-park','thiet-ke-biet-thu-vinhomes-ocean-park','oceanpark','Thiết Kế Biệt Thự Vinhomes Ocean Park | Dự Án HOVI Việt Nam','Tổng hợp các dự án thiết kế biệt thự Vinhomes Ocean Park do HOVI Việt Nam thực hiện.',4,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(5,'Video','video','video','video','Video HOVI Việt Nam | Công trình thực tế & chia sẻ chuyên môn','Tổng hợp video công trình thực tế, hậu trường triển khai và kinh nghiệm thiết kế thi công từ HOVI Việt Nam.',5,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(6,'Blog','blog','blog','blog','Blog HOVI Việt Nam | Chia sẻ thiết kế cảnh quan','Chuyên mục Blog của HOVI Việt Nam: kiến thức thiết kế cảnh quan, kinh nghiệm thi công và xu hướng không gian sống.',6,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(7,'Biệt thự đơn lập M07-L14 Dương Nội','biet-thu-don-lap-m07-l14-dtm-duong-noi','biet-thu-don-lap-m07-l14-dtm-duong-noi','project','Biệt Thự Đơn Lập M07-L14 ĐTM Dương Nội | Dự Án HOVI Việt Nam','Chi tiết dự án biệt thự đơn lập M07-L14 ĐTM Dương Nội của HOVI Việt Nam với hình ảnh phối cảnh.',7,1,'2026-04-15 04:15:26','2026-04-15 04:15:26'),(8,'Đăng ký dịch vụ','dang-ky-dich-vu','dang-ky-dich-vu','contact','Đăng Ký Dịch Vụ HOVI Việt Nam | Tư Vấn Thiết Kế Thi Công Biệt Thự','Đăng ký dịch vụ thiết kế thi công biệt thự cao cấp tại HOVI Việt Nam. Để lại thông tin để đội ngũ tư vấn liên hệ sớm nhất.',8,1,'2026-04-15 04:15:26','2026-04-15 04:15:26');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `personal_access_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `personal_access_tokens` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint unsigned NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `personal_access_tokens` WRITE;
/*!40000 ALTER TABLE `personal_access_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `personal_access_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `project_blogs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_blogs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `excerpt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_blogs_slug_unique` (`slug`),
  KEY `project_blogs_project_id_sort_order_index` (`project_id`,`sort_order`),
  CONSTRAINT `project_blogs_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `project_blogs` WRITE;
/*!40000 ALTER TABLE `project_blogs` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_blogs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `project_detail_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_detail_pages` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `summary` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `thumbnail_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_click_action` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'link',
  `gallery_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_detail_pages_slug_unique` (`slug`),
  KEY `project_detail_pages_project_id_sort_order_index` (`project_id`,`sort_order`),
  CONSTRAINT `project_detail_pages_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `project_detail_pages` WRITE;
/*!40000 ALTER TABLE `project_detail_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_detail_pages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `project_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `project_videos` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `project_id` bigint unsigned NOT NULL,
  `title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `video_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `thumbnail_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `content` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `display_zone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'all',
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `published_at` timestamp NULL DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `project_videos_slug_unique` (`slug`),
  KEY `project_videos_project_id_sort_order_index` (`project_id`,`sort_order`),
  KEY `project_videos_display_zone_index` (`display_zone`),
  CONSTRAINT `project_videos_project_id_foreign` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `project_videos` WRITE;
/*!40000 ALTER TABLE `project_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_videos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `projects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `projects` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `intro` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cover_image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `seo_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_published` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `projects_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (3,'Penthouse The River Thủ Thiêm','thiet-ke-chung-cu','Penthouse The River Thủ Thiêm- Cảnh quan',NULL,'/uploads/projects/project-cover-20260417045529-Oyw880pI.jpg',NULL,NULL,0,1,'2026-04-17 04:55:29','2026-04-17 06:05:01');
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `site_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `site_settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `site_settings` WRITE;
/*!40000 ALTER TABLE `site_settings` DISABLE KEYS */;
INSERT INTO `site_settings` VALUES (1,'site_name','HOVI Việt Nam','2026-04-15 04:15:26','2026-04-15 04:15:26'),(2,'site_tagline','Thiết kế và thi công cảnh quan, sân vườn cao cấp cho biệt thự và penthouse.','2026-04-15 04:15:26','2026-04-15 04:15:26'),(3,'header_logo','/theme/logoMenuRight1.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(4,'footer_logo','/theme/logofooter.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(5,'favicon','/theme/logohome.png','2026-04-15 04:15:26','2026-04-15 04:15:26'),(6,'seo_default_title','HOVI Việt Nam | Thiết Kế & Thi Công Cảnh Quan, Sân Vườn Cao Cấp','2026-04-15 04:15:26','2026-04-15 04:15:26'),(7,'seo_default_description','HOVI Việt Nam chuyên thiết kế, thi công cảnh quan và sân vườn cao cấp cho biệt thự, penthouse và khu đô thị.','2026-04-15 04:15:27','2026-04-15 04:15:27'),(8,'seo_keywords','thiết kế cảnh quan, thi công sân vườn, biệt thự, penthouse, HOVI Việt Nam','2026-04-15 04:15:27','2026-04-16 01:19:39'),(9,'seo_robots','index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1','2026-04-15 04:15:27','2026-04-15 04:15:27'),(10,'seo_canonical_base','https://hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(11,'seo_og_image','/theme/logohome.png','2026-04-15 04:15:27','2026-04-15 04:15:27'),(12,'footer_company_name','CÔNG TY TNHH HOVI VIỆT NAM','2026-04-15 04:15:27','2026-04-15 04:15:27'),(13,'footer_tax_code','2301198445','2026-04-15 04:15:27','2026-04-15 04:15:27'),(14,'footer_address','BT6 KĐT Việt Hưng, Long Biên, Hà Nội','2026-04-15 04:15:27','2026-04-15 04:15:27'),(15,'footer_website','https://hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(16,'footer_email','hovivietnam99@gmail.com','2026-04-15 04:15:27','2026-04-15 04:15:27'),(17,'footer_phone','0902103585','2026-04-15 04:15:27','2026-04-16 07:45:16'),(18,'footer_copyright','© HOVI Việt Nam','2026-04-15 04:15:27','2026-04-15 04:15:27'),(19,'social_facebook','https://hovi.com.vn','2026-04-15 04:15:27','2026-04-16 07:47:42'),(20,'social_tiktok','https://hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(21,'social_youtube','https://hovi.com.vn','2026-04-15 04:15:27','2026-04-15 04:15:27'),(22,'social_messenger','https://hovi.com.vn/','2026-04-15 04:15:27','2026-04-16 07:48:18'),(23,'social_zalo','https://zalo.me/0902103585','2026-04-15 04:15:27','2026-04-16 07:45:16'),(24,'about_content','{\"hero\":{\"enabled\":true,\"eyebrow\":\"About Us\",\"title\":\"HOVI VIỆT NAM - THIẾT KẾ & THI CÔNG CẢNH QUAN, SÂN VƯỜN CAO CẤP\",\"description\":\"Thành lập từ năm 2021, HOVI Việt Nam mang sứ mệnh đưa thiên nhiên vào không gian sống một cách nghệ thuật, tinh tế và bền vững. Chúng tôi tập trung vào các giải pháp cảnh quan cá nhân hóa cho biệt thự, penthouse và không gian dịch vụ.\",\"image\":\"/theme/assets/hovi/about-hero.png\",\"image_alt\":\"Cảnh quan sân vườn HOVI Việt Nam\"},\"mission\":{\"enabled\":true,\"title\":\"Sứ mệnh\",\"description\":\"Kiến tạo những không gian xanh “độc bản”, kết hợp thẩm mỹ và công năng để nâng cao chất lượng sống, sức khỏe tinh thần và giá trị lâu dài cho từng công trình.\",\"image\":\"/theme/assets/hovi/about-mission.png\",\"image_alt\":\"Không gian xanh biệt thự - HOVI Việt Nam\"},\"vision\":{\"enabled\":true,\"title\":\"Tầm nhìn\",\"description\":\"Trở thành đơn vị dẫn đầu trong lĩnh vực thiết kế cảnh quan thông minh (Smart Landscape) tại Việt Nam, kết hợp hài hòa giữa kiến trúc hiện đại và hệ sinh thái tự nhiên.\",\"image\":\"/theme/assets/hovi/about-vision.png\",\"image_alt\":\"Thiết kế sân vườn phong cách hiện đại\"},\"inspiration\":{\"enabled\":true,\"title\":\"Cảm hứng thương hiệu\",\"subtitle\":\"HOVI - Garden Flowers\",\"description\":\"HOVI theo đuổi triết lý “Tinh tế - Chu đáo, Sáng tạo - Đam mê”, mang tinh thần thủ công chỉn chu vào từng chi tiết cảnh quan để mỗi không gian đều có bản sắc riêng và giá trị sử dụng bền vững.\",\"image\":\"/theme/assets/hovi/about-inspiration.png\",\"image_alt\":\"Cảm hứng cảnh quan bonsai nghệ thuật\"},\"definition\":{\"enabled\":true,\"title\":\"HOVI: Không gian xanh cho phong cách sống hiện đại\",\"description\":\"Chúng tôi tin rằng sân vườn không chỉ là phần “trang trí”, mà là lá phổi xanh của ngôi nhà và là nơi tái tạo năng lượng mỗi ngày. HOVI ứng dụng thiết kế 3D trực quan, thi công đúng chuẩn và bảo hành dài hạn để đảm bảo chất lượng.\"},\"core\":{\"enabled\":true,\"heading\":\"Giá trị cốt lõi\",\"items\":[{\"title\":\"Tinh tế\",\"description\":\"Mỗi chi tiết cảnh quan được cân chỉnh hài hòa theo kiến trúc, công năng và trải nghiệm sử dụng thực tế.\",\"image\":\"/theme/assets/hovi/about-core-1.jpg\",\"image_alt\":\"Tinh tế\"},{\"title\":\"Chu đáo\",\"description\":\"Lắng nghe kỹ nhu cầu khách hàng, đồng hành xuyên suốt từ tư vấn, thiết kế đến chăm sóc sau bàn giao.\",\"image\":\"/theme/assets/hovi/about-core-2.jpg\",\"image_alt\":\"Chu đáo\"},{\"title\":\"Sáng tạo\",\"description\":\"Liên tục cập nhật xu hướng và công nghệ để mang đến giải pháp thiết kế độc bản cho từng công trình.\",\"image\":\"/theme/assets/hovi/about-core-3.jpg\",\"image_alt\":\"Sáng tạo\"},{\"title\":\"Đam mê\",\"description\":\"Đội ngũ HOVI đặt trọn tâm huyết vào từng dự án để mỗi khu vườn đều có chiều sâu cảm xúc riêng.\",\"image\":\"/theme/assets/hovi/about-core-4.jpg\",\"image_alt\":\"Đam mê\"},{\"title\":\"Chuyên nghiệp\",\"description\":\"Quy trình làm việc rõ ràng, vật tư minh bạch và thi công theo tiêu chuẩn kỹ thuật đã cam kết.\",\"image\":\"/theme/assets/hovi/about-core-5.jpg\",\"image_alt\":\"Chuyên nghiệp\"},{\"title\":\"Bền vững\",\"description\":\"Ưu tiên giải pháp xanh, tối ưu bảo trì và bảo hành dài hạn để cảnh quan giữ được vẻ đẹp lâu dài.\",\"image\":\"/theme/assets/hovi/about-core-6.jpg\",\"image_alt\":\"Bền vững\"}]},\"manifesto\":{\"enabled\":true,\"heading\":\"Cam kết thương hiệu\",\"items\":[{\"quote\":\"“Mỗi bản vẽ là một câu chuyện riêng, phù hợp phong cách và phong thủy của gia chủ.”\",\"image\":\"/theme/assets/hovi/about-manifesto-1.jpg\",\"image_alt\":\"Cam kết 1\"},{\"quote\":\"“Thiết kế trực quan bằng 3D để khách hàng nhìn thấy rõ không gian trước khi thi công.”\",\"image\":\"/theme/assets/hovi/about-manifesto-2.jpg\",\"image_alt\":\"Cam kết 2\"},{\"quote\":\"“Thi công đúng tiến độ, đúng chủng loại vật liệu và đồng hành bảo hành dài hạn.”\",\"image\":\"/theme/assets/hovi/about-manifesto-3.jpg\",\"image_alt\":\"Cam kết 3\"}]},\"advantages\":{\"enabled\":true,\"title\":\"Lợi thế cạnh tranh\",\"image\":\"/theme/assets/hovi/about-advantages.png\",\"image_alt\":\"Lợi thế cạnh tranh HOVI Việt Nam\",\"items\":[{\"title\":\"Cá nhân hóa thiết kế\",\"description\":\"mỗi phương án được xây dựng theo gu sống, ngân sách và hiện trạng thực tế.\"},{\"title\":\"Ứng dụng công nghệ\",\"description\":\"mô phỏng 3D trực quan giúp chốt phương án nhanh và giảm sai lệch thi công.\"},{\"title\":\"Thi công chuẩn kỹ thuật\",\"description\":\"quy trình chặt chẽ, kiểm soát vật tư và chất lượng theo từng hạng mục.\"},{\"title\":\"Đúng tiến độ\",\"description\":\"phối hợp đồng bộ giữa thiết kế, cung ứng và thi công để bàn giao đúng cam kết.\"},{\"title\":\"Hậu mãi rõ ràng\",\"description\":\"bảo dưỡng định kỳ và bảo hành dài hạn để cảnh quan luôn đẹp theo thời gian.\"}]},\"ceo\":{\"enabled\":true,\"eyebrow\":\"Thông điệp từ HOVI Việt Nam\",\"title\":\"Đội ngũ sáng lập\",\"description_1\":\"“Trong nhịp sống hiện đại, sân vườn không chỉ là khoảng xanh quanh nhà mà còn là nơi tái tạo năng lượng và thể hiện phong cách sống của gia chủ. Đó là lý do HOVI theo đuổi các giải pháp cảnh quan vừa đẹp, vừa bền vững.”\",\"description_2\":\"Chúng tôi trân trọng mọi cơ hội hợp tác và tin rằng sự đồng hành giữa HOVI với đối tác, khách hàng sẽ tạo nên những công trình giàu cảm hứng, nâng cao giá trị thương hiệu và chất lượng sống.\",\"image\":\"/theme/assets/hovi/about-ceo.png\",\"image_alt\":\"Đội ngũ sáng lập HOVI Việt Nam\"},\"capacity\":{\"enabled\":true,\"heading\":\"Hồ sơ năng lực\",\"lead\":\"HOVI cung cấp dịch vụ thiết kế - thi công sân vườn biệt thự, tiểu cảnh hồ cá koi, trang trí ban công/penthouse và các gói decor sự kiện, set up hoa theo yêu cầu cho không gian cao cấp.\",\"stats\":[{\"value\":\"Since 2021\",\"label\":\"Khởi tạo thương hiệu\"},{\"value\":\"05\",\"label\":\"Bước quy trình chuẩn\"},{\"value\":\"04\",\"label\":\"Nhóm sản phẩm mẫu\"},{\"value\":\"Dài hạn\",\"label\":\"Bảo hành & chăm sóc\"}],\"action_1_label\":\"NHẬN HỒ SƠ NĂNG LỰC\",\"action_1_url\":\"mailto:hovivietnam99@gmail.com\",\"action_2_label\":\"ĐẶT LỊCH TƯ VẤN\",\"action_2_url\":\"/lien-he\"}}','2026-04-15 04:15:27','2026-04-18 08:44:00'),(25,'home_content','{\"hero\":{\"background_image\":\"/uploads/home/home-hero-bg-20260416071259-xRAPXCD3.jpg\",\"scroll_target\":\"#projects-1\"},\"profile\":{\"background_image\":\"/uploads/home/home-profile-bg-20260416071259-SPwwakg4.jpg\",\"eyebrow\":\"Hồ sơ năng lực\",\"title\":\"Không gian được thiết kế như một tuyên ngôn sống\",\"description_1\":\"Thấu hiểu rằng mỗi công trình là hiện thân của những ước mơ và cá tính riêng của khách hàng, HOVI VIỆT NAM luôn đặt sự tận tâm với nghề và nỗ lực sáng tạo lên hàng đầu để mang tới những không gian kết hợp hài hòa giữa tầm nhìn nghệ thuật của kiến trúc sư và nhu cầu sử dụng thực tế.\",\"description_2\":\"Với HOVI VIỆT NAM, hạnh phúc lớn nhất là được đồng hành cùng khách hàng trên hành trình kiến tạo tổ ấm. Chính sự tin tưởng đó là động lực để đội ngũ không ngừng hoàn thiện, phát triển và nâng chuẩn dịch vụ.\",\"button_label\":\"Catalogue HOVI VIỆT NAM\",\"button_url\":\"#footer\",\"slider_images\":[\"/uploads/home/home-profile-slider-20260416073456-4oNXReBR.jpg\",\"/uploads/home/home-profile-slider-20260416073456-KyidSpvu.jpg\",\"/uploads/home/home-profile-slider-20260416073456-dmec4LFt.jpg\",\"/uploads/home/home-profile-slider-20260416073456-KbgU37q3.jpg\",\"/uploads/home/home-profile-slider-20260416073456-VabRxZjl.jpg\",\"/uploads/home/home-profile-slider-20260416073456-tf6iFwxn.jpg\"]},\"about\":{\"title\":\"Về HOVI VIỆT NAM\",\"description\":\"Kể từ khi thành lập vào năm 2021, chúng tôi không ngừng khẳng định vị thế là một trong những đơn vị mang đến cho khách hàng giải pháp nâng tầm không gian toàn diện hàng đầu, từ khâu thiết kế và thi công kiến trúc sân vườn và sự kiện. Trong một thị trường biệt thự đầy cạnh tranh, HOVI VIỆT NAM được tin - yêu không chỉ bởi mức độ xuất sắc của sản phẩm mà còn bởi dịch vụ tư vấn và đồng hành cùng khách hàng sau khi tiếp nhận yêu cầu.\",\"stats\":[{\"value\":\"10+\",\"label\":\"Năm kinh nghiệm\"},{\"value\":\"80\",\"label\":\"Nhân sự\"},{\"value\":\"100\",\"label\":\"Khách hàng\"},{\"value\":\"100+\",\"label\":\"Dự án thi công\"}],\"cta_label\":\"XEM THÊM\",\"cta_url\":\"/about-us\",\"team_image\":\"/theme/assets/hovi/gallery/hovi-060.jpg\"},\"footer_cta\":{\"consult\":{\"title\":\"ĐẶT LỊCH TƯ VẤN\",\"button_label\":\"Đặt lịch\",\"button_url\":\"/dang-ky-dich-vu\",\"background_image\":\"/uploads/home/home-footer-consult-20260416071259-ZYf3pGPQ.jpg\"},\"partner\":{\"title\":\"TRỞ THÀNH ĐỐI TÁC HOVI VIỆT NAM\",\"button_label\":\"Tham gia\",\"button_url\":\"/lien-he\",\"background_image\":\"/uploads/home/home-footer-partner-20260416071259-jFHjQazB.jpg\"}},\"project_highlights\":{\"mode\":\"manual\",\"items\":[{\"title\":null,\"description\":\"Penthouse the river Thủ Thiêm\",\"image\":\"/uploads/home/home-highlight-20260418083935-XhzKTmMW.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null},{\"title\":null,\"description\":null,\"image\":\"/uploads/home/home-highlight-20260418083953-hTeDEe8h.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null},{\"title\":null,\"description\":null,\"image\":\"/uploads/home/home-highlight-20260418084011-XkdpKEt9.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null},{\"title\":null,\"description\":null,\"image\":\"/uploads/home/home-highlight-20260418084120-pnpltHZ7.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null},{\"title\":null,\"description\":null,\"image\":\"/uploads/home/home-highlight-20260418084120-S3nS2eBS.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null},{\"title\":null,\"description\":null,\"image\":\"/uploads/home/home-highlight-20260418084120-jBoJjlou.jpg\",\"action\":\"lightbox\",\"link_type\":null,\"link_value\":null}],\"auto_excluded_detail_page_ids\":[]}}','2026-04-15 04:15:27','2026-04-18 08:41:20'),(26,'apple_touch_icon','/theme/logohome.png','2026-04-16 07:42:13','2026-04-16 07:42:13'),(27,'seo_google_site_verification',NULL,'2026-04-16 07:42:13','2026-04-16 07:42:13');
/*!40000 ALTER TABLE `site_settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'HOVI Admin','admin@hovi.local',NULL,'$2y$10$HzFLFlpvWdFT6urDfSVHB.2e8LsCYzptGejaR5zHxe4h8wBqi9h6S','enAFnnD3JUBUUm1W8evcCUJxWIBZTfsqCRAZQxq3co7EnfdjMVX4jwD3sW0j','2026-04-15 04:15:26','2026-04-16 01:19:39');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

